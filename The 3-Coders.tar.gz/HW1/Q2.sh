mkdir Question2_Assn1
cd Question2_Assn1
git init 
touch 11940550.txt
echo "iitbhilai">>11940550.txt
cp 11940550.txt 11940650.txt
cp 11940550.txt 11941130.txt
mkdir Raveendra 
mkdir Ankith
mkdir Shreyash
mv 11940550.txt Raveendra 
mv 11940650.txt Ankith
mv 11941130.txt Shreyash
git add Raveendra
git commit -m "1st member is commited"
git graph
git add Ankith 
git commit -m "2nd member is commited"
git graph
git add Shreyash
git commit -m "3rd member is commited"
git graph
