git init 'Question1_Assn1'
cd 'Question1_Assn1'
echo 'iitbhilai' > 11940550
echo 'iitbhilai' > 11940650
echo 'iitbhilai' > 11941130
mkdir Raveendra
mkdir Ankith
mkdir Shreyash
chmod 750 Raveendra
chmod 750 Ankith
chmod 750 Shreyash
mv -i 11940550 Raveendra
mv -i 11940650 Ankith
mv -i 11941130 Shreyash
git add -A
git commit -m "Commit0"
git graph
